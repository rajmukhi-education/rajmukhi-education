# Deployment Checklist

- [ ] Production environment variables configured
- [ ] HTTPS/SSL enabled
- [ ] Database backup schedule configured
- [ ] SMTP configured
- [ ] Admin credentials secured
- [ ] File upload storage reviewed
- [ ] Health endpoint verified
- [ ] Login and 2FA tested
- [ ] Certificate verification tested
- [ ] Privacy settings tested
- [ ] Error logging/monitoring configured
