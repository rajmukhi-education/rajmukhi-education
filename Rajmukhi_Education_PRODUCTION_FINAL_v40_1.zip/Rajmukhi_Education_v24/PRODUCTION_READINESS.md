# Rajmukhi Education — Production Readiness

Version: 40.1.0
Status: Production Finalization

## Before deployment
1. Copy `.env.example` to `.env` and configure production secrets.
2. Use HTTPS and a secure reverse proxy.
3. Configure a production database and scheduled backups.
4. Configure SMTP for password reset and security notifications.
5. Set a strong random `SESSION_SECRET`.
6. Run the health check after deployment.
7. Verify admin recovery procedures.

## Final acceptance checklist
- Student registration/login
- Course enrollment and learning progress
- Lesson completion
- Test submission and result display
- Certificate generation and verification
- Profile/privacy controls
- 2FA and recovery codes
- Session/device revocation
- Security audit
- Personal data export
- Admin management and analytics
