Rajmukhi Education v12

New features:
- Secure token-based student/admin authentication
- Student registration and login
- Admin login via environment variables
- Protected results API
- Protected admin content APIs
- Test Creator API
- Local upload storage endpoint
- Persistent JSON database

Run:
  npm start

Default admin:
  email: admin@rajmukhi.education
  password: 1234

For production, set:
  ADMIN_EMAIL=your-email
  ADMIN_PASSWORD=strong-password
  PORT=3000

API examples:
  GET /api/health
  POST /api/auth/register
  POST /api/auth/login
  GET /api/auth/me
  POST /api/admin/tests
  POST /api/admin/upload
