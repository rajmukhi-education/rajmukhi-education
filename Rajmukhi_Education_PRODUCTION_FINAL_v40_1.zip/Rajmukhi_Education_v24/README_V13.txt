Rajmukhi Education V13
=======================

V13 improvements:
- Functional Admin Dashboard
- Dynamic Test UI: all tests from backend can be attempted
- Dynamic result submission for logged-in students
- Video Classes module with external links and local MP4/WebM playback
- Admin can add video classes
- File upload UI for PDF/images/videos through protected admin API
- Uploaded files are stored in /uploads and tracked in the database
- Improved content manager for Courses, Notes/PDF links, and Notices
- Search across courses, notes, tests and videos
- Better MIME handling for uploaded files

Run:
1. Install Node.js
2. In this folder run: npm start
3. Open: http://localhost:3000

Default admin:
Email: admin@rajmukhi.education
Password: 1234

For production, change ADMIN_EMAIL and ADMIN_PASSWORD environment variables and use a real database/cloud storage.
