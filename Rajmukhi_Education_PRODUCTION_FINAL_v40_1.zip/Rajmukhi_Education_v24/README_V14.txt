Rajmukhi Education V14
=======================
New:
- Course detail screen with lessons
- Student course enrollment
- Lesson completion/progress tracking
- Student progress API
- Expanded persistent JSON database
- Version upgraded to v14

Run:
1. npm install
2. node server.js
3. Open index.html
Default admin:
Email: admin@rajmukhi.education
Password: 1234
For production, change ADMIN_EMAIL and ADMIN_PASSWORD environment variables.
