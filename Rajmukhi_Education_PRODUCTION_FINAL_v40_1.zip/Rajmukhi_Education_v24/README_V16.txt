Rajmukhi Education V16
=======================
New:
- Professional media viewer foundation
- PDF/notes viewer support
- Video class viewer with YouTube embed support
- Lesson content viewer
- Static uploads route for PDF/video/image assets
- Version upgraded to v16

Run:
1. npm install
2. node server.js
3. Open index.html
