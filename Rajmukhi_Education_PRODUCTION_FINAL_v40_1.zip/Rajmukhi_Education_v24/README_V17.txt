Rajmukhi Education V17
=======================
New:
- Real admin file upload endpoint
- PDF, video and image upload support
- Uploaded files stored in uploads/
- Upload metadata persisted in database
- Protected upload route
- Version upgraded to v17

Run:
1. npm install
2. node server.js
3. Open index.html
