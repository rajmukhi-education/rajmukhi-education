Rajmukhi Education V18
=======================

V18 completion release.

Major improvements:
- Fixed the V17 upload flow: browser file uploads now correctly convert to Base64 JSON for the API.
- API health now reports V18.
- Student dashboard API: enrollment, completed lessons, attempts and course-wise progress.
- Admin dashboard API: complete content and activity counts plus recent results.
- Admin content deletion API for courses, notes, videos, notices, tests and lessons.
- Existing authentication, enrollment, lesson progress, dynamic tests, results, media viewer and persistent JSON database retained.

Run:
1. Install Node.js
2. Open this folder in terminal
3. Run: npm start
4. Open http://localhost:3000

Default admin:
Email: admin@rajmukhi.education
Password: 1234

For production:
- Change ADMIN_EMAIL and ADMIN_PASSWORD.
- Use HTTPS and a real database.
- Add stronger password hashing, rate limiting and cloud storage.
