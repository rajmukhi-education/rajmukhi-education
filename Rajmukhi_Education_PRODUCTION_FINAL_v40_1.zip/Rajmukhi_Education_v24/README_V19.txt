Rajmukhi Education V19
=======================

V19 upgrade release.

Major improvements:
- Student Learning Dashboard now shows enrolled courses, completed lessons, test attempts and course-wise progress percentages.
- Student dashboard includes recent test results.
- Admin Dashboard now loads live analytics: students, courses, lessons, tests, attempts and uploads.
- Admin Dashboard shows recent test activity.
- Added logout flow that invalidates the current server session.
- API health now reports V19 and the new dashboard/analytics features.
- Existing V18 features retained: authentication, uploads, lessons, enrollments, progress tracking, tests, results, videos and persistent JSON database.

Run:
1. Install Node.js
2. Open this folder in terminal
3. Run: npm start
4. Open http://localhost:3000

Default admin:
Email: admin@rajmukhi.education
Password: 1234
