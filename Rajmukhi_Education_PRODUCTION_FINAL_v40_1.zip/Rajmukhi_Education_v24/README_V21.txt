Rajmukhi Education V21

Admin Dashboard UI is available at:
GET /admin

Features:
- Overview analytics
- Students list
- Courses management
- Lessons view
- Results view
- Notes, videos, notices and tests content summary
- Course creation
- Content deletion
- Refresh and logout
- Responsive mobile layout
