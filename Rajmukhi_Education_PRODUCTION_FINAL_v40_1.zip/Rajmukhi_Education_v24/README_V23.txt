Rajmukhi Education V23
=======================

V23 completion release.

Major improvements:
- Admin Dashboard now uses the live V23 dashboard summary API.
- Functional admin content management: add and delete courses, lessons, tests, notes, videos and notices.
- Recent result analytics and platform counts.
- Added admin content aggregation endpoint.
- Added update-ready course and test API routes.
- API health version updated to V23.
- Existing authentication, enrollment, lesson progress, dynamic tests, results, media viewer and persistent JSON database retained.

Run:
1. Install Node.js
2. Open this folder in terminal
3. Run: npm start
4. Open http://localhost:3000

Default admin:
Email: admin@rajmukhi.education
Password: 1234

For production:
- Change ADMIN_EMAIL and ADMIN_PASSWORD.
- Use HTTPS and a real database.
- Add stronger password hashing, rate limiting and cloud storage.
