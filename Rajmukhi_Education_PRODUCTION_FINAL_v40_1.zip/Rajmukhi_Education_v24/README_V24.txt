Rajmukhi Education V24
=======================

V24 Admin Management release.

Major improvements:
- Fixed the V23 admin asset mismatch so /admin reliably loads its dashboard files.
- Rebuilt Admin Dashboard as V24 with live overview statistics.
- Full course CRUD: create, edit and delete courses.
- Full lesson CRUD: create, edit and delete lessons with course mapping and content.
- Full test CRUD: create and edit tests with multiple questions, options and correct answers.
- Content management for Notes, Videos and Notices with delete actions.
- Results dashboard with latest-first sorting.
- Preserved authentication, enrollment, progress, dynamic tests, results, uploads and JSON database.
- API startup version updated to V24.

Run:
1. Install Node.js
2. Open this folder in terminal
3. Run: npm start
4. Open http://localhost:3000

Default admin:
Email: admin@rajmukhi.education
Password: 1234
