Rajmukhi Education V25
=======================

V25 Admin Management & Analytics release.

Major improvements:
- Advanced student management with search and role filtering.
- Student detail view with enrollments, progress, attempts and average score.
- Admin enrollment control: enroll and remove students from courses.
- New admin analytics endpoint with enrollment totals, average score, active students in the last 30 days and course enrollment statistics.
- Overview dashboard upgraded with enrollment and performance insights.
- Student/test names shown in results instead of only IDs.
- V25 admin assets are isolated and /admin loads the V25 dashboard.
- Existing authentication, courses, lessons, tests, content, results, uploads and JSON database preserved.

Run:
1. Install Node.js
2. Open this folder in terminal
3. Run: npm start
4. Open http://localhost:3000

Default admin:
Email: admin@rajmukhi.education
Password: 1234
