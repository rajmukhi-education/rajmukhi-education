Rajmukhi Education V27

Major release: Certificate Generation & Verification.

Features:
- Student course completion certificate generation.
- Unique certificate number (RDE-YEAR-XXXXXX).
- Certificate HTML view/print endpoint.
- Public certificate verification API: GET /api/certificates/verify/:certificateNo
- Student certificates API: GET /api/certificates
- Secure eligibility checks: authenticated user, enrollment and all course lessons completed.
- Existing V26 learning dashboard and analytics retained.
