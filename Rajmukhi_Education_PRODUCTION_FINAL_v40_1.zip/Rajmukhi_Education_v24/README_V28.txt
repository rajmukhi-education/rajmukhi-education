Rajmukhi Education V28

V28 adds a stronger certificate lifecycle:
- Public certificate verification page: /certificate/<CERTIFICATE_NO>
- Verification hash for each generated certificate
- Active/revoked certificate status
- Admin certificate search and management
- Admin certificate revocation with reason and timestamp
- Enhanced public verification API response
- Admin dashboard V28 certificate management section

Existing V27 features remain preserved.
