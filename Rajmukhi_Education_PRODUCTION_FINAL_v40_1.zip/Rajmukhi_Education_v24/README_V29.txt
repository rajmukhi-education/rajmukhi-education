Rajmukhi Education V29
=======================

V29 introduces a professional certificate and student profile layer.

Highlights:
- Print-ready A4 landscape certificate HTML with browser Print / Save as PDF.
- Certificate download metadata endpoint.
- Student profile API with enrollment, result and certificate summary.
- Public verification remains available through /certificate/:certificate_no.
- Health endpoint version updated to v29.

Certificate flow:
1. Student completes all lessons.
2. Student generates a certificate.
3. Student opens the certificate HTML.
4. Use Print / Save as PDF from the browser to create a PDF copy.
5. Verification is available from the public certificate verification page.
