Rajmukhi Education — V30

V30 upgrades the student-facing profile and certificate experience:
- Dedicated /profile dashboard
- Profile editing for name and email with validation
- Course enrollment overview
- Test attempt and average score summary
- Certificate gallery with View/Print and shareable verification links
- V30 API health feature flags
- Existing V29 certificate verification and management preserved
