Rajmukhi Education — V31

V31 upgrades the student profile into a personal account center.

Features:
- Student settings and notification preferences
- Secure password change with current-password verification
- All active sessions are invalidated after password change
- Student profile dashboard remains compatible with V30
- Certificate gallery, sharing and print-ready certificate preserved
- Progress/profile integration remains backward compatible

API:
GET/PUT /api/profile/settings
PUT /api/profile/password
GET /api/profile/student
PUT /api/profile/student

Version: 31.0.0
