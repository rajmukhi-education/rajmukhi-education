Rajmukhi Education — V32

V32 introduces a dedicated Settings & Security center.

Features:
- Professional settings page
- Profile photo/avatar upload and removal
- Login activity view
- Privacy controls: private/students/public visibility and email display preference
- Notification preference management
- Existing secure password change flow retained
- V31 profile and certificate features preserved

Routes:
GET /settings
GET /api/profile/activity
PUT /api/profile/avatar
DELETE /api/profile/avatar
GET/PUT /api/profile/settings
PUT /api/profile/password
