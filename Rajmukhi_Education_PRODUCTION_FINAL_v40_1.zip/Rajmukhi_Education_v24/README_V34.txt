Rajmukhi Education V34

V34 adds real TOTP-based two-factor authentication. Users can enroll an authenticator secret, confirm a 6-digit code, and must complete a 2FA challenge during login when enabled.

Endpoints:
POST /api/profile/2fa/setup
POST /api/profile/2fa/confirm
POST /api/profile/2fa/disable
POST /api/auth/2fa/verify

Security events are recorded for setup, enable, login challenge, verified login and disable actions.
