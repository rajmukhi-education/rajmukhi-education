Rajmukhi Education V37

Major additions:
- Privacy Controls API: profile visibility, email visibility, learning reminders, certificate updates and product notifications.
- New Security & Privacy Center at /security.
- Admin Security Audit Dashboard at /admin.
- Admin endpoint: GET /api/admin/security-audit.
- Session activity now includes device label and device id metadata.
- V37 health feature flags added.
