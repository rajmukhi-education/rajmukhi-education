Rajmukhi Education V38

- Admin security audit filtering by event type, user and keyword.
- CSV export for security audit events.
- Privacy-aware public profile API respecting private/students/public visibility.
- V38 health feature registry and package version update.
