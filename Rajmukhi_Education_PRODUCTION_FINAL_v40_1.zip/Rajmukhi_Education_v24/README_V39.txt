Rajmukhi Education V39

Features:
- Privacy-aware public student profile API and page
- Shareable public profile route: /public-profile?id=STUDENT_ID
- Public achievements summary
- Public certificate showcase respecting profile visibility
- Profile visibility and email privacy controls preserved
- V39 package version and API branding updated
