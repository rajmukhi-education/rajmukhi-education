# Rajmukhi Education V22

- Advanced responsive admin dashboard
- Overview analytics cards
- Students, courses, lessons, tests, content and results sections
- V22 admin assets and changelog
