# V25 Changelog

## Admin Management
- Student search by name/email.
- Role filter.
- Student detail modal.
- Course enrollment and unenrollment controls.

## Analytics
- Total enrollments.
- Average test score.
- Active students over the last 30 days.
- Enrollment breakdown by course.

## Technical
- Added `/api/admin/analytics`.
- Added admin enrollment POST/DELETE endpoints.
- Updated API health version to v25.
- Updated admin asset routing to V25.
