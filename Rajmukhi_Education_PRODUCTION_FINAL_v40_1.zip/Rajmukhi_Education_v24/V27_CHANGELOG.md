# V27 Changelog

## Certificate System
- Added persistent `certificates` database collection.
- Added `/api/certificates/generate`.
- Added `/api/certificates`.
- Added `/api/certificates/:certificateNo/html`.
- Added `/api/certificates/verify/:certificateNo`.
- Added student dashboard certificate generation button.
- Added printable certificate design with unique certificate number.

## Compatibility
- Existing V26 APIs and features retained.
