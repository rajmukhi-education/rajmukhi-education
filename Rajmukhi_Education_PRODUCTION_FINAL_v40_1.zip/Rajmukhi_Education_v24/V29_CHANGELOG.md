# V29 Changelog

## Certificate Experience
- Added print-ready professional certificate layout.
- Added A4 landscape print styling.
- Added browser Print / Save as PDF action.
- Added certificate download metadata endpoint.

## Student Profile
- Added `/api/profile/student` for profile, enrollments, results and certificates.

## Platform
- Health version updated to v29.
- Existing authentication, learning, analytics and certificate verification flows preserved.
