# V30 Changelog

## Student Profile & Certificate Experience
- Added dedicated `/profile` frontend dashboard.
- Added authenticated `PUT /api/profile/student` for profile editing.
- Added course, test, score, and certificate summary cards.
- Added certificate gallery with print and shareable verification links.
- Updated health endpoint to V30.
- Preserved V29 authentication, certificate generation, verification, revocation, and profile APIs.
