# V31 Changelog

## Student Account Center
- Added settings endpoint for notification preferences.
- Added password-change endpoint with current password validation.
- Password change invalidates all active sessions for the account.
- Added V31 profile page with Settings & Security controls.
- Updated API health version and feature flags.
