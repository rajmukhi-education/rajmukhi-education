# V32 Change Log

- Added dedicated Settings & Security page.
- Added avatar upload/remove support.
- Added login activity view.
- Added privacy controls.
- Added V32 API feature flags and health version.
- Preserved V31 profile, certificate, notification and password-security functionality.
