# V33 CHANGELOG

- Security Center upgraded
- Active session management and revoke-other-sessions
- Security event audit log
- 2FA/OTP-ready setup and disable endpoints
- Settings page upgraded to V33
- Health API version updated to v33
