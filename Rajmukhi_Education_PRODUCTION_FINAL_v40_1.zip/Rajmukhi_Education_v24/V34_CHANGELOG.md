# V34 Changelog

- Added real TOTP-based 2FA using authenticator apps.
- Added secure 2FA enrollment and confirmation flow.
- Added login challenge and verification endpoint.
- Added expiry for pending 2FA challenges.
- Added security event logging for 2FA lifecycle events.
- Updated health API and package version to V34.
