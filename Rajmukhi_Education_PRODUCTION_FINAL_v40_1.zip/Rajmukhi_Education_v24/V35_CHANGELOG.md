# Rajmukhi Education V35

- Trusted device/session labels and per-session revoke API
- Security alerts for new logins
- Recovery codes for TOTP 2FA
- One-time recovery code login support
- Recovery code regeneration protected by authenticator code
- Security Center page at `/security`
- V35 health/features metadata
