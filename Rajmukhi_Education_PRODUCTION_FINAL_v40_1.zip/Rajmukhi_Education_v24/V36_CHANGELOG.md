# V36 Changelog

- Upgraded Security Center to V36
- Added personal data export endpoint: GET /api/profile/data-export
- Added downloadable JSON export from Security Center
- Added V36 health/features metadata
- Preserved V35 TOTP 2FA, recovery codes, trusted sessions and alerts
