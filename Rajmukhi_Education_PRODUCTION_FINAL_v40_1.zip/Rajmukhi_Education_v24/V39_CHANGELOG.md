# V39 Changelog

- Added privacy-aware public student profile endpoint.
- Added shareable public profile page.
- Added achievements summary based on learning activity and certificates.
- Added public certificate showcase while respecting profile visibility.
- Updated package version to 39.0.0 and server branding to V39.
