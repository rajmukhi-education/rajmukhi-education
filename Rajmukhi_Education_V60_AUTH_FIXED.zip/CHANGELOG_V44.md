# V44 Changelog

- Bumped application version to v44-production / package 44.0.0.
- Added `/api/ready` readiness endpoint.
- Added `/api/version` runtime information endpoint.
- Added admin-only `/api/admin/integrity` diagnostics for orphaned references.
- Preserved existing authentication, 2FA, sessions, certificates, profiles, privacy, uploads, and security features.
