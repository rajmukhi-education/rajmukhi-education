# V46 Deployment Checklist

## Required environment
- `NODE_ENV=production`
- `PORT` (optional; defaults to 3000)
- `ADMIN_EMAIL`
- `ADMIN_PASSWORD`

## Persistence
Persist:
- `data.json`
- `uploads/`

## Smoke tests
- `GET /api/health` -> `ok: true`
- `GET /api/ready` -> `ready: true`
- `GET /api/version` -> `v46-production`
- `GET /` -> `200`
- Register/login flow -> successful
- Authenticated `/api/dashboard/student` -> `200`

## Security
- Use HTTPS in public deployment.
- Do not use the default admin password.
- Keep `data.json` and `uploads/` on persistent storage.
