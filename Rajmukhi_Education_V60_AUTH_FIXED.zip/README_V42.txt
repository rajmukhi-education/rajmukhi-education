Rajmukhi Education V42 — Production Hardening

V42 is based on V41_FIXED and preserves the existing application features.

Added:
- Working root route `/` serving the main application.
- Production API version reporting: v42-production.
- Security response headers on API and HTML routes.
- Login, registration and 2FA verification rate limiting.
- Safer production HTTPS security header when NODE_ENV=production.
- Graceful shutdown handling for Render/Node deployments.
- Improved static file serving and deployment resilience.

Run:
npm start

Production:
Set NODE_ENV=production, ADMIN_EMAIL and a strong ADMIN_PASSWORD before deployment.
