Rajmukhi Education V43 — Stability & Maintenance

V43 is based on V42 and keeps all existing application features.

Added:
- Unique X-Request-ID on every request for easier debugging and support.
- Request timeout protection for stalled requests.
- Automatic cleanup of expired sessions and expired 2FA challenges.
- Cleanup timer is safely stopped during graceful shutdown.
- Version updated to v43-production.
- Existing authentication, 2FA, courses, lessons, tests, certificates, profiles, privacy and admin security features preserved.

Run:
npm start

Production:
Set NODE_ENV=production, ADMIN_EMAIL and a strong ADMIN_PASSWORD before deployment.
