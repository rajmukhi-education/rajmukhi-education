Rajmukhi Education V44

V44 adds production readiness and integrity diagnostics.

New endpoints:
- GET /api/ready — readiness check for database and uploads directory.
- GET /api/version — runtime/version information.
- GET /api/admin/integrity — admin-only data integrity and orphan-reference diagnostics.

Existing V43 features remain preserved.
