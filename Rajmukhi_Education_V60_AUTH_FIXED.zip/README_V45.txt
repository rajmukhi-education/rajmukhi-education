Rajmukhi Education V45

Deep end-to-end testing and stabilization release.

Key fixes:
- Removed duplicate root route and kept a single static-file serving path.
- Fixed public profile privacy so email is not exposed unless the user explicitly enables show_email.
- Fixed public certificate field mapping to the actual certificate schema (certificate_no, course_title, issued_at, status).
- Fixed student dashboard certificate action to generate/view the certificate instead of showing an outdated placeholder message.
- Improved oversized JSON body handling so oversized requests are rejected instead of silently destroying the connection.
- Updated application version to v45-production / 45.0.0.

Validation performed:
- Node syntax check passed.
- Production-mode server boot passed.
- /api/health returned 200.
- /api/ready returned 200.
- /api/version returned 200.
- Main website route returned 200.
- Course listing returned 200.
- Registration, authenticated /api/auth/me, and student dashboard flow returned expected responses.
