Rajmukhi Education V46
=======================

V46 is the deployment-readiness release built on V45.

Changes:
- Added Docker deployment support using Node 22 Alpine.
- Added production startup warning when ADMIN_EMAIL/ADMIN_PASSWORD are not configured.
- Updated production version to v46.
- Added deployment verification checklist.

Before public deployment:
1. Set NODE_ENV=production.
2. Set a strong ADMIN_EMAIL and ADMIN_PASSWORD.
3. Use a persistent volume for data.json and uploads/.
4. Put the app behind HTTPS/reverse proxy.
5. Run the included smoke tests/checks against the deployed URL.
