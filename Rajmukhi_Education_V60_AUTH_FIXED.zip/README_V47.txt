Rajmukhi Education V47

V47 is an operational hardening release based on V46.

Changes:
- Atomic database persistence: writes go to data.json.tmp and are renamed into place.
- Readiness checks now verify database directory and uploads directory writability.
- Admin-only /api/admin/diagnostics endpoint for operational inspection.
- Version updated to v47-production / 47.0.0.

Before public deployment:
- Set ADMIN_EMAIL and ADMIN_PASSWORD environment variables.
- Persist data.json and uploads/ outside ephemeral container storage.
- Use HTTPS/reverse proxy in front of the Node server.
