Rajmukhi Education V48
======================

V48 focuses on the safest next step after production hardening: protecting the app's data and making recovery simple.

New in V48:
- Automatic backup utility: `npm run backup`
- Restore utility: `npm run restore -- backups/<backup-file>.json`
- Persistent `backups/` directory
- Admin diagnostics now reports backup count and latest backup
- Server version: v48-production

Important:
- Keep the `data.json`, `uploads/`, and `backups/` folders persistent when hosting.
- Do not expose backup JSON files publicly.
- Before public deployment, set ADMIN_EMAIL and ADMIN_PASSWORD environment variables.

The application itself remains compatible with the existing V47 data format.
