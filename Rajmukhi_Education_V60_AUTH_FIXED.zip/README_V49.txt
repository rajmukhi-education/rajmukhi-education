Rajmukhi Education V49
======================

V49 focuses on automatic data protection and operational reliability.

Improvements:
- Automatic backup is created at startup and then periodically.
- Backup retention is configurable with BACKUP_RETENTION (default 14).
- Backup interval is configurable with BACKUP_INTERVAL_MS (default 24 hours; minimum 6 hours).
- Automatic backups use format rajmukhi-education-backup-v2 and include a SHA-256 checksum.
- Backups are written atomically before being retained.
- Existing V48 backup/restore tools remain available.
- Existing authentication, 2FA, courses, lessons, tests, certificates, profiles, privacy and security features are preserved.

The app remains a Node.js application. No manual code changes are required for normal use.
