Rajmukhi Education V50
======================

V50 focuses on backup integrity verification and safer recovery.

Improvements:
- Added SHA-256 integrity verification for automatic V49 backups.
- Added `verify-backup.js` CLI for checking an individual backup before restore.
- Restore now verifies the checksum of V2 automatic backups before replacing the database.
- Added admin endpoint `/api/admin/backups/verify` for backup integrity status.
- Admin diagnostics now include automatic-backup integrity counts and verification results.
- Existing authentication, 2FA, courses, lessons, tests, certificates, profiles, privacy, security, backup and restore features are preserved.

The app remains a Node.js application.
