Rajmukhi Education — V52

V52 fixes the production frontend JavaScript syntax error that prevented the Home dashboard from rendering after deployment. It also connects course detail pages to the live lesson API, adds enrollment action, and updates the production version marker to v52.
