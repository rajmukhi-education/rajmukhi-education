Rajmukhi Education V54
=======================

Lesson Reader Upgrade

- Added dedicated lesson reading view.
- Added lesson progress indicator.
- Added Previous / Next lesson navigation.
- Added Mark as completed / Mark incomplete.
- Added automatic move to the next lesson after completion.
- Existing V53 backend and data are preserved.
