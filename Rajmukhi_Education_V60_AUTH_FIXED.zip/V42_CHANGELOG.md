# V42 Changelog

- Based on V41_FIXED.
- Added reliable `/` main application route.
- Added security headers: nosniff, frame protection, referrer policy and production HSTS.
- Added basic rate limiting for registration, login and 2FA verification attempts.
- Added production version identifier `v42-production` to health endpoint.
- Added graceful SIGTERM/SIGINT shutdown for hosted deployments.
- Updated package version to 42.0.0.
