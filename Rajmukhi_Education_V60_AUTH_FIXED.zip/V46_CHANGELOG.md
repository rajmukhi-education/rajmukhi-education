# V46 Changelog

## Deployment Readiness
- Added `Dockerfile` for Node 22 Alpine deployment.
- Added `.dockerignore` to avoid shipping local database and upload contents.
- Added production startup warning when default admin credentials would otherwise be used.
- Updated application version to `v46-production` / package `46.0.0`.
- Added deployment checklist and operational guidance.

## Validation
- Node syntax validation passed.
- Local server smoke tests passed for health, readiness, version, root route, courses, registration, login, and authenticated dashboard flow.
