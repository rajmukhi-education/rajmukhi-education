# V47 Changelog

## Production hardening
- Added atomic `data.json` writes using temporary-file replacement.
- Expanded `/api/ready` to check write access for the database directory and uploads directory.
- Added admin-authenticated `/api/admin/diagnostics` for runtime, memory, database counts, and upload storage visibility.
- Updated package version to 47.0.0.
