# V49 Changelog

## Automatic backup protection
- Added automatic backup creation on startup and on a configurable interval.
- Added retention cleanup for automatic backups.
- Added SHA-256 checksum metadata to automatic backup files.
- Added atomic write behavior for automatic backup files.
- Added configurable `BACKUP_RETENTION` and `BACKUP_INTERVAL_MS` environment variables.
- Preserved existing manual backup and restore tooling.

## Reliability
- Automatic backup timer is cleaned up during graceful shutdown.
- Existing V48 API, authentication, 2FA, certificate, profile, privacy and security features remain intact.
