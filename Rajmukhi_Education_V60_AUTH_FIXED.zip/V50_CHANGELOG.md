# V50 Changelog

## Backup integrity and safer recovery
- Added automatic-backup integrity verification using the existing SHA-256 checksum.
- Added `verify-backup.js` command for pre-restore verification.
- Updated restore tooling to reject tampered or corrupted V2 automatic backups.
- Added admin API endpoint `GET /api/admin/backups/verify`.
- Extended admin diagnostics with backup integrity status.

## Compatibility
- V49 automatic backups remain compatible.
- V48/V49 manual restore behavior remains available for legacy V1 backups.
- Existing authentication, 2FA, course, lesson, test, certificate, profile, privacy and security features remain intact.
