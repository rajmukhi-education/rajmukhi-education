# V52 Changelog

- Fixed a JavaScript syntax error in the certificate generation UI that prevented the entire frontend script from parsing.
- Course detail pages now load actual lessons from `/api/lessons?course_id=...` instead of showing placeholder chapters.
- Added student enrollment action from course details.
- Updated backend and package version to v52.
