# Rajmukhi Education V55

## Student Learning Experience
- Added a dedicated My Learning card on the Home page.
- Added My Learning access from the student profile.
- Session initialization now refreshes enrollment and lesson-progress data.
- Course list shows an Enrolled badge for courses the student has joined.
- Kept V54 lesson reader, progress tracking, previous/next navigation, and completion flow.
- Backend unchanged; existing V53/V54 API compatibility preserved.
