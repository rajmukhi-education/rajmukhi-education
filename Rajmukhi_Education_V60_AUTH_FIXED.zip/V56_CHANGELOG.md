# V56 – Study Material Content

- Added full Hindi study material to Introduction to General Science.
- Added revision points and completion instruction.
- Updated My Learning dashboard version badge to V56.
