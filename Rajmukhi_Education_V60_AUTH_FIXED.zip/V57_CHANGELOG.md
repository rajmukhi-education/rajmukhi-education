# Rajmukhi Education V57

## Lesson Study Material & Read Tracking Fix
- Fixed lesson cards opened from the course page so they load their lesson content from the API.
- Added readable paragraph/list formatting for lesson study material.
- Preserved Mark as completed / Mark incomplete progress tracking.
- Preserved previous/next lesson navigation.
