# V58 Changelog

- Fixed Mark as completed progress saving.
- Added explicit lesson/course validation on progress API.
- Added saving state and visible success state to completion button.
- Dashboard progress now refreshes from saved completion data.
