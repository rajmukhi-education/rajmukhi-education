# V59 CHANGELOG

## Fix: Mark as completed
- Fixed lesson completion button click handling.
- Removed fragile inline click handler and attached a reliable event listener after lesson rendering.
- Completion is saved through `POST /api/progress`.
- After saving, the lesson is reloaded so the button state updates immediately.
- Dashboard progress can now reflect the saved completion after refresh.
