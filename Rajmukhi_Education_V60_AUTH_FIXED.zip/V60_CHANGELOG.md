# V60 Changelog
- Fixed lesson completion authentication/session handling.
- Shows clear login prompt when session is missing or expired.
- Handles authentication-required errors by clearing stale session and reopening Student Login.
- Mark as completed now saves progress through the authenticated API and refreshes lesson state.
